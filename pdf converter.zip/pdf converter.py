import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
import os

# Crée une fonction pour la conversion
def convertir_odt_en_pdf(chemin_odt):
    # Définit le chemin de l'exécutable LibreOffice (ajustez-le si nécessaire)
    if os.name == 'nt':  # Si le système est Windows
        soffice_path = r"C:\Program Files\LibreOffice\program\soffice.exe"
    else:  # Si le système est macOS ou Linux
        soffice_path = "libreoffice"

    # Crée le chemin du dossier de sortie
    repertoire_de_sortie = os.path.dirname(chemin_odt)

    # Commande à exécuter
    commande = [
        soffice_path,
        "--headless",  # Mode sans interface graphique
        "--convert-to", "pdf",
        chemin_odt,
        "--outdir", repertoire_de_sortie
    ]
    
    try:
        # Exécute la commande
        subprocess.run(commande, check=True)
        messagebox.showinfo("Succès", "Le fichier a été converti en PDF avec succès !")
    except FileNotFoundError:
        messagebox.showerror("Erreur", "LibreOffice n'a pas été trouvé. Assurez-vous qu'il est installé et que son chemin est correct.")
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Erreur de conversion", f"Une erreur est survenue lors de la conversion : {e}")

# Crée la fonction pour le bouton "Convertir"
def ouvrir_explorateur_et_convertir():
    # Ouvre la boîte de dialogue pour sélectionner un fichier .odt
    chemin_odt = filedialog.askopenfilename(
        title="Sélectionnez un fichier ODT à convertir en PDF",
        filetypes=(("Fichiers OpenDocument", "*.odt"), ("Tous les fichiers", "*.*"))
    )

    # Si un fichier est sélectionné, lance la conversion
    if chemin_odt:
        convertir_odt_en_pdf(chemin_odt)

# Crée la fenêtre principale
fenetre = tk.Tk()
fenetre.title("Convertisseur ODT vers PDF")
fenetre.geometry("400x200")

# Crée un widget bouton
bouton = tk.Button(
    fenetre,
    text="Sélectionner et convertir en PDF",
    command=ouvrir_explorateur_et_convertir
)

# Place le bouton dans la fenêtre
bouton.pack(pady=50)

# Lance la boucle principale
fenetre.mainloop()